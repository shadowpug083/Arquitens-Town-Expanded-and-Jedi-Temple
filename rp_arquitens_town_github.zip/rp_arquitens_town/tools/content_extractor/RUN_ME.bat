@echo off
rem Copies the Arquitens content rp_arquitens_town uses into .\rp_arquitens_town_content
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0extract_content.ps1" %*
pause
