# Pulls only the files rp_arquitens_town uses out of the Arquitens Workshop addon (.gma),
# so the map can be published without the 1.7 GB base addon as a requirement.
#
#   Double-click RUN_ME.bat, or:
#   powershell -ExecutionPolicy Bypass -File extract_content.ps1 [-Gma <path to gmpublisher.gma>] [-Out <folder>]
#
# What it does:
#   1. reads the list of models / materials / sounds the map refers to (needed_seed.txt)
#   2. finds each one inside the Arquitens .gma and copies it out
#   3. follows what they need in turn: a model's materials and mesh files, a material's textures,
#      particle and soundscape files
#   4. skips anything the rp_arquitens_town addon already ships (already_shipped.txt) and anything
#      that comes with Garry's Mod itself (those aren't in the .gma)
#   5. writes a report (content_report.txt) next to the output folder

param(
    [string]$Gma = "",
    [string]$Out = ""
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $Out) { $Out = Join-Path $here "rp_arquitens_town_content" }

if (-not $Gma) {
    $candidates = @(
        "D:\SteamLibrary\steamapps\workshop\content\4000\3622448623\gmpublisher.gma",
        "C:\Program Files (x86)\Steam\steamapps\workshop\content\4000\3622448623\gmpublisher.gma"
    )
    foreach ($c in $candidates) { if (Test-Path -LiteralPath $c) { $Gma = $c; break } }
    if (-not $Gma) {
        foreach ($root in @("D:\SteamLibrary\steamapps\workshop\content\4000\3622448623", "C:\Program Files (x86)\Steam\steamapps\workshop\content\4000\3622448623")) {
            if (Test-Path -LiteralPath $root) {
                $f = Get-ChildItem -LiteralPath $root -Filter *.gma | Select-Object -First 1
                if ($f) { $Gma = $f.FullName; break }
            }
        }
    }
}
if (-not $Gma -or -not (Test-Path -LiteralPath $Gma)) {
    Write-Host "Couldn't find the Arquitens .gma. Run again with -Gma ""<path to the .gma>""." -ForegroundColor Red
    exit 1
}
Write-Host "Reading $Gma"

# ------------------------------------------------------------------ read the .gma table of contents
$fs = [System.IO.File]::OpenRead($Gma)
$br = New-Object System.IO.BinaryReader($fs)
function Read-CString {
    $bytes = New-Object System.Collections.Generic.List[byte]
    while ($true) {
        $b = $br.ReadByte()
        if ($b -eq 0) { break }
        $bytes.Add($b)
    }
    return [System.Text.Encoding]::UTF8.GetString($bytes.ToArray())
}
$magic = [System.Text.Encoding]::ASCII.GetString($br.ReadBytes(4))
if ($magic -ne "GMAD") { Write-Host "Not a .gma file: $Gma" -ForegroundColor Red; exit 1 }
$ver = $br.ReadByte()
[void]$br.ReadUInt64()   # steam id
[void]$br.ReadUInt64()   # timestamp
if ($ver -gt 1) { while ((Read-CString) -ne "") { } }   # required content list
[void](Read-CString); [void](Read-CString); [void](Read-CString)   # name, description, author
[void]$br.ReadInt32()    # addon version

$index = @{}
$entries = New-Object System.Collections.Generic.List[object]
$offset = [int64]0
while ($true) {
    $num = $br.ReadUInt32()
    if ($num -eq 0) { break }
    $name = Read-CString
    $size = $br.ReadInt64()
    [void]$br.ReadUInt32()   # crc
    $key = $name.ToLowerInvariant().Replace('\', '/')
    $index[$key] = @{ Name = $name; Offset = $offset; Size = $size }
    $offset += $size
}
$dataStart = $fs.Position
Write-Host ("{0} files in the addon" -f $index.Count)

# ------------------------------------------------------------------ inputs
$seed = Get-Content -LiteralPath (Join-Path $here "needed_seed.txt") | Where-Object { $_ -ne "" }
$skip = @{}
$shippedFile = Join-Path $here "already_shipped.txt"
if (Test-Path -LiteralPath $shippedFile) {
    foreach ($s in Get-Content -LiteralPath $shippedFile) { if ($s) { $skip[$s.ToLowerInvariant()] = $true } }
}

function Get-Bytes([string]$key) {
    $e = $index[$key]
    $fs.Position = $dataStart + $e.Offset
    return $br.ReadBytes([int]$e.Size)
}

$done = @{}
$queue = New-Object System.Collections.Generic.Queue[string]
$missing = New-Object System.Collections.Generic.List[string]
$copied = 0; $bytesOut = [int64]0
function Want([string]$p) {
    $k = $p.ToLowerInvariant().Replace('\', '/').TrimStart('/')
    while ($k.Contains('//')) { $k = $k.Replace('//', '/') }
    if (-not $done.ContainsKey($k)) { $done[$k] = $true; $queue.Enqueue($k) }
}
foreach ($s in $seed) { Want $s }

function Material-Of([string]$tok) {
    $t = $tok.Trim().Trim('"').ToLowerInvariant().Replace('\', '/')
    if ($t.StartsWith("materials/")) { $t = $t.Substring(10) }
    if ($t.EndsWith(".vtf") -or $t.EndsWith(".vmt")) { $t = $t.Substring(0, $t.Length - 4) }
    return $t
}

$soundscapeSources = New-Object System.Collections.Generic.List[string]
$particleManifests = New-Object System.Collections.Generic.List[string]
foreach ($k in $index.Keys) {
    if ($k -like "scripts/soundscapes_*arquitens*.txt") { $soundscapeSources.Add($k) }
    if ($k -like "maps/*arquitens*_particles.txt") { $particleManifests.Add($k) }
}
# particle effects (waterfalls, leaves): every particle file in the addon, they're small
$pcfs = New-Object System.Collections.Generic.List[string]
foreach ($k in $index.Keys) { if ($k.StartsWith("particles/") -and $k.EndsWith(".pcf")) { $pcfs.Add($k); Want $k } }
foreach ($k in $soundscapeSources) { Want $k }
foreach ($k in $particleManifests) { Want $k }

# ------------------------------------------------------------------ copy and follow references
while ($queue.Count -gt 0) {
    $k = $queue.Dequeue()
    if ($skip.ContainsKey($k)) { continue }
    if (-not $index.ContainsKey($k)) {
        if (-not ($k.EndsWith(".dx80.vtx") -or $k.EndsWith(".sw.vtx") -or $k.EndsWith(".phy") -or $k.EndsWith("_hdr.vmt") -or $k.EndsWith(".ani"))) { $missing.Add($k) }
        continue
    }
    $bytes = Get-Bytes $k
    $dest = Join-Path $Out ($index[$k].Name.Replace('/', '\'))
    $dir = Split-Path -Parent $dest
    if (-not (Test-Path -LiteralPath $dir)) { [void](New-Item -ItemType Directory -Force -Path $dir) }
    [System.IO.File]::WriteAllBytes($dest, $bytes)
    $copied++; $bytesOut += $bytes.Length

    if ($k.EndsWith(".mdl")) {
        $stem = $k.Substring(0, $k.Length - 4)
        foreach ($ext in @(".vvd", ".dx90.vtx", ".phy", ".ani")) { Want ($stem + $ext) }
        try {
            $nt = [BitConverter]::ToInt32($bytes, 204); $ti = [BitConverter]::ToInt32($bytes, 208)
            $nc = [BitConverter]::ToInt32($bytes, 212); $ci = [BitConverter]::ToInt32($bytes, 216)
            $names = @(); $cds = @()
            for ($i = 0; $i -lt $nt; $i++) {
                $o = $ti + 64 * $i; $so = $o + [BitConverter]::ToInt32($bytes, $o)
                $e = [Array]::IndexOf($bytes, [byte]0, $so)
                $names += [System.Text.Encoding]::ASCII.GetString($bytes, $so, $e - $so)
            }
            for ($i = 0; $i -lt $nc; $i++) {
                $so = [BitConverter]::ToInt32($bytes, $ci + 4 * $i)
                $e = [Array]::IndexOf($bytes, [byte]0, $so)
                $cds += [System.Text.Encoding]::ASCII.GetString($bytes, $so, $e - $so)
            }
            foreach ($n in $names) {
                $found = $false
                foreach ($c in $cds) {
                    $cand = ("materials/" + $c + $n + ".vmt").ToLowerInvariant().Replace('\', '/')
                    while ($cand.Contains('//')) { $cand = $cand.Replace('//', '/') }
                    if ($index.ContainsKey($cand) -or $skip.ContainsKey($cand)) { Want $cand; $found = $true }
                }
                if (-not $found -and $cds.Count -gt 0) { Want ("materials/" + $cds[0] + $n + ".vmt") }
            }
        } catch { $missing.Add("(couldn't read textures of) " + $k) }
    }
    elseif ($k.EndsWith(".vmt")) {
        $text = [System.Text.Encoding]::UTF8.GetString($bytes)
        foreach ($m in [regex]::Matches($text, '"([^"\r\n]+)"|([^\s"{}]+)')) {
            $tok = if ($m.Groups[1].Success) { $m.Groups[1].Value } else { $m.Groups[2].Value }
            if ($tok.StartsWith('$') -or $tok.StartsWith('%') -or $tok.Length -lt 3) { continue }
            $t = Material-Of $tok
            if ($t -eq "env_cubemap") { continue }
            if ($index.ContainsKey("materials/$t.vtf")) { Want "materials/$t.vtf" }
            if ($index.ContainsKey("materials/$t.vmt")) { Want "materials/$t.vmt" }
            $raw = $tok.ToLowerInvariant().Replace('\', '/')
            if ($index.ContainsKey($raw)) { Want $raw }   # "include" "materials/x.vmt" (patch materials)
        }
    }
    elseif ($k.EndsWith(".pcf")) {
        $text = [System.Text.Encoding]::ASCII.GetString($bytes)
        foreach ($m in [regex]::Matches($text, '[A-Za-z0-9_\-/\\\.]+\.vmt')) { Want ("materials/" + $m.Value) }
    }
    elseif ($k.StartsWith("scripts/soundscapes_")) {
        $text = [System.Text.Encoding]::UTF8.GetString($bytes)
        foreach ($m in [regex]::Matches($text, '"wave"\s+"([^"]+)"')) { Want ("sound/" + $m.Groups[1].Value.TrimStart('*', '#', '@', '^', '!', ')', '(', '<', '>', '}', '$')) }
        # the same soundscapes under this map's name, so the game loads them for rp_arquitens_town
        $copy = Join-Path $Out "scripts\soundscapes_rp_arquitens_town.txt"
        if (-not (Test-Path -LiteralPath $copy)) { [System.IO.File]::WriteAllBytes($copy, $bytes) }
    }
    elseif ($k.StartsWith("maps/") -and $k.EndsWith("_particles.txt")) {
        $text = [System.Text.Encoding]::UTF8.GetString($bytes)
        foreach ($m in [regex]::Matches($text, '"file"\s+"!?([^"]+)"')) { Want $m.Groups[1].Value }
        $copy = Join-Path $Out "maps\rp_arquitens_town_particles.txt"
        if (-not (Test-Path -LiteralPath $copy)) { [System.IO.File]::WriteAllBytes($copy, $bytes) }
    }
}
$br.Close(); $fs.Close()

# no particle manifest for the map in the addon: write one so the map's particle effects load
$manifest = Join-Path $Out "maps\rp_arquitens_town_particles.txt"
if (-not (Test-Path -LiteralPath $manifest) -and $pcfs.Count -gt 0) {
    $ml = @("particles_manifest", "{")
    foreach ($p in $pcfs) { $ml += ('    "file" "!' + $index[$p].Name + '"') }
    $ml += "}"
    $mdir = Split-Path -Parent $manifest
    if (-not (Test-Path -LiteralPath $mdir)) { [void](New-Item -ItemType Directory -Force -Path $mdir) }
    Set-Content -LiteralPath $manifest -Value $ml
}

# the soundscape / particle copies made under the map's own name don't belong to the original addon files
foreach ($k in $soundscapeSources + $particleManifests) {
    $p = Join-Path $Out ($index[$k].Name.Replace('/', '\'))
    if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p }
}

$report = Join-Path (Split-Path -Parent $Out) "content_report.txt"
$lines = @("Copied $copied files, {0:N1} MB, into $Out" -f ($bytesOut / 1MB), "",
           "Referenced but not in the Arquitens addon (normally Garry's Mod / Half-Life 2 base content, which every player has):")
$lines += ($missing | Sort-Object -Unique)
Set-Content -LiteralPath $report -Value $lines
Write-Host ""
Write-Host ("Done: {0} files, {1:N1} MB copied to {2}" -f $copied, ($bytesOut / 1MB), $Out) -ForegroundColor Green
Write-Host "Report: $report"
